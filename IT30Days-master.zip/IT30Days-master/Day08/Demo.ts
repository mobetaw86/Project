// app.ts
import { Facade } from './Facade';

const facade: Facade = new Facade();
facade.punishmentMakeMistakeEmployee();
facade.RewardNormalEmployee();