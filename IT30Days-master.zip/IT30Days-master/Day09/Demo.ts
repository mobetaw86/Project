// app.ts
import { Mediator } from './Mediator';
//我沒特別寫觸發
//因為沒特別想員工觸發方式 暫時Demo是無效的 僅為概念
const mediator: Mediator = new Mediator();
