import {Shape} from './Shape';
import {Circle} from './Circle';
import {ShapeFactory} from './ShapeFactory';

let Greencircle:Shape = ShapeFactory.getCircle('Green');
let Greencircle2:Shape = ShapeFactory.getCircle('Green');
let Yellowcircle:Shape = ShapeFactory.getCircle('Yellow');
let Redcircle:Shape = ShapeFactory.getCircle('red');
let Yellowcircle2:Shape = ShapeFactory.getCircle('Yellow');

