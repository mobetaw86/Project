import {Shape} from './Shape';

export class Circle implements Shape{
    constructor(){
        
    }
    draw():void{
        console.log('draw a Circle');
    }
}