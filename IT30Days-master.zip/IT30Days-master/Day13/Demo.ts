import {Person} from './Person';

let person:Person = new Person();

person.chat();
person.login();
person.chat();
person.login();
person.logout();