export interface State{
    chat():void;
    login():void;
    logout():void;
}