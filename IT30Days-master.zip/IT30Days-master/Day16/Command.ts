export interface Command{
    execute():void;
}