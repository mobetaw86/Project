
export class Door{
    open():void{
        console.log('door is open');
    }
    close():void{
        console.log('door is close');
    }
}