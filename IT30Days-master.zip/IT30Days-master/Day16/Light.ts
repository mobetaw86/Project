
export class Light{
    
    on():void{
        console.log('light is on');
    }
    off():void{
        console.log('light is off');
    }
}