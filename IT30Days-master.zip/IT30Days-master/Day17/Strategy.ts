export interface Strategy{
    Operation():void;
    getName():string;
}