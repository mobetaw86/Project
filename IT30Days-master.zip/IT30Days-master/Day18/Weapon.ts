
export interface Weapon{
    attack():void;
}