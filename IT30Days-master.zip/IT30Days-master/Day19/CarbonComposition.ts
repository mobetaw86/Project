import {Composition} from './Composition';

export class  CarbonComposition implements Composition{
    storePower():void{
        console.log('Storing in CarbonComposition');
    }   
}