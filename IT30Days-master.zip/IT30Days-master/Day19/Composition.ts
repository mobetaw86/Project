
export interface Composition{
    storePower():void;
}