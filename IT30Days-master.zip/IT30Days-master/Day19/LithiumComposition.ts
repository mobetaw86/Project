import {Composition} from './Composition';

export class LithiumComposition implements Composition{
    storePower():void{
        console.log('Storing in LithiumBattery');
    }   
}