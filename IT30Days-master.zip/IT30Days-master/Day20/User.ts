export interface User{
    chat():void;
}