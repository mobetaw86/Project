import {Player} from './Player';
import {AudioPlayer} from './AudioPlayer';

let player:Player = new AudioPlayer();
player.play();