export class OldPlayer{
    playTheMusicPlease(oldSetting:string):void{
        console.log('playing...')
    }
}