export interface Player{
    play():void;
}