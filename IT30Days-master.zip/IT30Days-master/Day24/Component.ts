
export interface Component{
    getTaste():string;
}