import {Component} from './Component';

export class Salt implements Component{
    getTaste():string{
        return '有點鹹鹹的~';
    }
}