import {Iterator} from './Iterator';
export interface Aggregate{
    iterator():Iterator;
}