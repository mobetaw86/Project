export interface Iterator{
    hasNext():boolean;
    next():Object;   
}