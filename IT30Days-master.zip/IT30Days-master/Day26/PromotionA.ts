import {AbstractPromotion} from './AbstractPromotion';
export class PromotionA extends AbstractPromotion{    
    use():void{
        console.log('Use PromotionA');
    }
}