import {AbstractPromotion} from './AbstractPromotion';
export class PromotionB extends AbstractPromotion{
    use():void{
        console.log('Use PromotionB');
    }
}