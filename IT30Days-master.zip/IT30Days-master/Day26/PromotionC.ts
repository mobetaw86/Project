import {AbstractPromotion} from './AbstractPromotion';
export class PromotionC extends AbstractPromotion{
    use():void{
        console.log('Use PromotionC');
    }
}