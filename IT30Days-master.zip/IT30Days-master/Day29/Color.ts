export interface Color{
    fill():void;
}